FLAG — Frontline Advisory Group
Staging build

This build is configured for Vercel and intentionally includes:
- noindex,nofollow meta tags on all HTML pages while under review
- clean URLs via vercel.json
- basic security headers

Before production launch:
1. Remove the noindex,nofollow meta tags.
2. Replace placeholder contact details/form handling.
3. Add final canonical URLs / social sharing metadata.
4. Connect frontlineadvisory.ca only after approval.
