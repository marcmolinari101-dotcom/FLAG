FLAG — Frontline Advisory Group | Website V3

Pages
- index.html — homepage
- services.html — service offering
- advisors.html — generic team experience (no individual bios)
- contact.html — placeholder contact details and preview form

Design direction
Minimal, cinematic, editorial presentation using supplied photography. Production credits are intentionally omitted until publication permissions are confirmed.

Before launch
1. Confirm final company name/spelling and logo treatment.
2. Supply final enquiry email and phone number.
3. Connect the contact form to the chosen email/form provider.
4. Confirm rights/permissions for every photograph.
5. Confirm that all visible agency/employer identifiers are acceptable for public use; replace or edit any that are not.
6. Confirm whether any production credits may be named publicly.
7. Add analytics and final SEO metadata.
8. Test mobile/tablet/desktop and accessibility.

Staging
This is a static site and can be uploaded as-is to a private/static staging host. Set the published directory to the folder containing index.html. A custom domain can be connected after approval.
